<script setup>
import HelloWorld from './components/HelloWorld.vue'
import login from './components/login.vue'
import home from './components/home.vue'
// import Certificate from './components/Certificate.vue'
// import ModifyInformation from './components/ModifyInformation.vue'


</script>

<template>
  <HelloWorld/>
  <login/>
  <home/> 
  <!-- <Certificate/>
  <ModifyInformation/> --> -->

</template>

<style scoped>

</style>
