<template>
<div>
  <!-- <div class="top" style="margin-top: 15px;" >
    <img src="logo.png">
  </div>
    <div class="login_top">
      <ul>
        <li>
          <a class="nav">首页</a>
        </li>
        <li>
          <a class="nav1" href="#/">个人中心</a>
        </li>
      </ul>
    </div>
    <div class="login_player">
      <from>
        <div class="login_context">
          <div class="login_context_top">
            <ul class="login_title">
              <li class="play1">
                <a>密码登入</a>
              </li>
              <li class="play">
                <a>短信登入</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="login_context2" style="min-width: 500px;">
          <div class="usernamediv">
            <label style="width: 35%;">Email/手机/用户名：</label>
            <input style="width: 60%;" type="text">
          </div>
          <div class="userpassworddiv">
            <label style="width: 35%;">密码：</label>
            <input style="width: 60%; " placeholder = "请输入登录密码" type="password">
          </div>
          <div class="usercodediv">
            <label style="width: 35%;">验证码：</label>
            <input style="width: 60%; " placeholder = "请输入图形验证码" type="text">
          </div>
        </div>
        <div style="text-align: center;">
          <input text="button" value="登入" class="login_submint"/>
          <input text="button" value="注册" class="login_submint" style="margin-left: 5%;"/>
        </div>
        <div class="login_context3">
          <label></label>
          <span>请“登录”后再开始使用、操作… …</span>
        </div>
      </from>
 </div>
  <div class="login_buttom">
    <ul style="width: 335px;">
      <li style="width: 92px;">
        <a href="http://www.moe.gov.cn">教育部</a>
        |
      </li>
      <li style="width: 235px;">
        <a href="http://www.moe.gov.cn">全国高校教师网络培训中心</a>
      </li>
    </ul>
    <div class="plays">
        <a href="http://resfile.enetedu.com/Content/webImg/www/images/icp.jpg?tim=20210416 09:09:40"  style="cursor:pointer;color:black;">京ICP证100673号</a>
        <a href="http://resfile.enetedu.com/Content/webImg/www/images/bbs.jpg?tim=20210416 09:09:40" style="cursor:pointer;color:black">电子公告许可证 </a>
        <a style="cursor:pointer;color:black" href="https://beian.miit.gov.cn">京ICP备08008005号-7</a>
        <a style="cursor:pointer;color:black" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010202008739">京公网安备11010202008739</a>
        <p>Copyright © 2007-2021 全国高校教师网络培训中心版权所有</p>
        <p>技术支持：北京畅想数字音像科技股份有限公司</p>
    </div>
  </div> -->
</div>
</template>

<script>
// import home from './home.vue'
// import login from './login.vue'
// const router = {
//   '/home': home,
//   '/login':login

// }
export default {
  setup() {
    
  },
}
</script>

<style scoped>
* {
      margin: 0;
      padding: 0;
      font-family: "微软雅黑";
    }
    .top{
      width: 32%;
      margin-left: 18%;
      margin-top: 30%;
    }
    .login_player{
      width: 50%;
      min-width: 500px;
      margin: 0 auto;
    }
    .login_top{
      width: 100%;
      height: 55px;
      background-color: #a81818;
    }
    li{
      width: 12.5%;
      float: left;;
      overflow: hidden;
      line-height: 55px;
      text-align: center;
      height: 55px;
    }
    .nav{
      display: inline-block;
      width: 100%;
      color: #fff;
    }
    .nav1{
      border:1px solid white;
      display: inline-block;
      width: 100%;
      color: #fff;
    }
    .login_context{
      margin: 0 auto;
      padding: 50px;
    }
    .login_context_top{
      margin: 0 auto;
    }
    .login_title{
      width: 100%;
      padding-bottom: 50Px;
    }
    .login_title li.play{
      border-bottom: 1px #bfbfbf solid;
    }
    .login_title li.play1{
      border-bottom: 2px #015293 solid;
    }
    .login_context ul li{
      width: 50%;
      float: left;
      text-align: center;
    }
    .login_context2 div{
      padding-bottom: 20px;
    }
    .login_context2 label{
      float: left;
      text-align: right;
      line-height: 40px;
      height: 40px;
      padding-right: 2%;
    }
    .login_context2 input{
      width: 60%;
      line-height: 40px;
      height: 40px;
      color: #b0b0b0;
      border: 1px #c0bfbf solid;
      border-radius: 5px;
      text-indent: 1em;
    }
    .login_submint{
      border: #fff;
      text-align: center;
      background-color: #fb645f;
      color: #fff;
      width: 210px;
      line-height: 45px;
      height: 45px;
      border-radius: 22px;
    }
    .login_context3{
      padding-top: 20px;
      padding-bottom: 20px;
      text-align: center;
    }
    .login_buttom{
      height: 205px;
      background-color: #f1f1f1;
      border: 1px #aaa solid;
      text-align: center;
      line-height: 28px;
    }
    .login_buttom ul {
      width: 50%;
      text-align: center;
      margin: 0 auto;
      margin-top: 14px;
      overflow: hidden;
      margin-bottom: 16px;
    }
    .login_buttom ul li{
      line-height: 28px;
      float: left;
      width: 19%;
      height: 24px;
    }
    .login_buttom ul li a{
      text-decoration:none;
      line-height: 28px;
      padding-right: 20px;
      color: #015293;
    }
    .login_buttom a:hover{
      text-decoration: underline;
    }
    a:hover{
      text-decoration: underline;
    }
</style>