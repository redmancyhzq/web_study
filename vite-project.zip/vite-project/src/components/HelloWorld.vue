<template>
  <div class="card">
    {{x}}
  </div>
  <button type="button" @click="add">点击x+1</button>
</template>
<script>
import { ref } from 'vue'
export default {
  setup() {
    let x =ref(1)
    
    let add =()=>{
      x.value++
      console.log(x)
    }
    return {x,add}
  }
}

</script>

<style scoped>
.card{
  background-color: aqua;
  width: 50px;
  height: 50px;
}
</style>
